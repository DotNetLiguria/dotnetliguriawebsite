﻿namespace TestLibrary
{
    using System;
    using System.Web;

    public class Class1
    {
        public static string GetUserAgent() => HttpContext.Current.Request.UserAgent;
        public static string GetUserAgentFromContext(HttpContextBase context) => HttpContext.Current.Request.UserAgent;
    }
}
