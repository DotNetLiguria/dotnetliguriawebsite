﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace SimpleMigrationImperia.Controllers
{
    public class ProvaController : Controller
    {
        // GET: Prova
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {

            ViewBag.Message = TestLibrary.Class1.GetUserAgent();
            return View();
        }
    }
}