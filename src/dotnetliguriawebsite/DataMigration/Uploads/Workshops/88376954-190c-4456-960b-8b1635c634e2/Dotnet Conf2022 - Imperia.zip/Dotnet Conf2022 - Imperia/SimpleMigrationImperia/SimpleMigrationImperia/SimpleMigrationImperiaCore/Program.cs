
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSystemWebAdapters();
builder.Services.AddReverseProxy().LoadFromConfig(builder.Configuration.GetSection("ReverseProxy"));

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();
app.UseSystemWebAdapters();

// Minimal api
app.MapGet("/test1", (HttpContext ctx) => TestLibrary.Class1.GetUserAgentFromContext(ctx));
app.MapGet("/test2", () => TestLibrary.Class1.GetUserAgent());

app.MapDefaultControllerRoute();
app.MapReverseProxy();

app.Run();
