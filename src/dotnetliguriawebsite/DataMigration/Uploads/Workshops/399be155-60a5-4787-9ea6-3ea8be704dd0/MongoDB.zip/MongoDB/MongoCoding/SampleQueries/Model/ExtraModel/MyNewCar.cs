﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleQueries.Model.ExtraModel
{
    public class MyNewCar : Car
    {
        public String Booo { get; set; }
    }
}
