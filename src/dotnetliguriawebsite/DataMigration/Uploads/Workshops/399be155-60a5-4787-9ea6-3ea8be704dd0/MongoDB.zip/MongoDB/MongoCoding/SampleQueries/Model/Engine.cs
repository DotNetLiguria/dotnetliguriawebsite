﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleQueries.Model
{
    public class Engine
    {
        public Guid Id { get; set; }
        public String Fuel { get; set; }
    }
}
