﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleQueries.Model
{
    public class User
    {
        public Guid Id { get; set; }
        public String Username { get; set; }
        public String Password { get; set; }
        public String Name { get; set; }
        public String Phone { get; set; }
        public List<String> Roles { get; set; }

        public User()
        {
            Id = Guid.NewGuid();
        }
    }
}
