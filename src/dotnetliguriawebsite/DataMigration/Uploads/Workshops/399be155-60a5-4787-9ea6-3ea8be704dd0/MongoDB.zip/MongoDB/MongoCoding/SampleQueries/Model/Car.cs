﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleQueries.Model
{
    public class Car
    {
        public Guid Id { get; set; }
        public String Make { get; set; }
        public String Model { get; set; }
        public Engine Engine { get; set; }
        public CarImage Image { get; set; }
    }
}
