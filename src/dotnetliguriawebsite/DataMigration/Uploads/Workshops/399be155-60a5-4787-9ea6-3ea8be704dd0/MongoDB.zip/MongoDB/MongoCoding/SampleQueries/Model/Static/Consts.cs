﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleQueries.Model.Static
{
    public class Roles
    {
        public const String Admin = "Admin";
        public const String Operator = "Operator";
    }

    public class FuelTypes
    {
        public const String Diesel = "Diesel";
        public const String Electric = "Electric";
        public const String Gasoline = "Gasoline";
        public const String Solar = "Solar";
    }

    public class MakeTypes
    {
        public const String Fiat = "Fiat";
        public const String Jeep = "Jeep";
        public const String Subaru = "Subaru";
        public const String Helios = "Helios";
    }

    public class Consts
    {
    }
}
