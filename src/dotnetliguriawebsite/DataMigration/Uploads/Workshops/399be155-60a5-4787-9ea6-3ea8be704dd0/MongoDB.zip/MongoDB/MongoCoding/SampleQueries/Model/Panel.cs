﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleQueries.Model
{
    public class Panel
    {
        public String Brand { get; set; }
        public Double Power { get; set; }
    }
}
