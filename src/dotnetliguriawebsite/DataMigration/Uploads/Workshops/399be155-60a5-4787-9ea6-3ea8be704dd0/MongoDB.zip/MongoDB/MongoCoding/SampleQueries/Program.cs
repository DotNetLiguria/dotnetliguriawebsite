﻿using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using SampleQueries.Model;
using SampleQueries.Model.ExtraModel;
using SampleQueries.Model.Static;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleQueries
{
    /// <summary>
    /// 
    ///                     mongod --dbpath ..\data -v --slowms=0
    /// 
    /// </summary>
    class Program
    {
        /// <summary>
        /// Link: http://docs.mongodb.org/manual/reference/connection-string/
        ///     mongodb://[username:password@]host1[:port1][,host2[:port2],...[,hostN[:portN]]][/[database][?options]]
        /// 
        /// Link: http://docs.mongodb.org/ecosystem/tutorial/authenticate-with-csharp-driver/
        ///     var connectionString = "mongodb://user1:password1@localhost/test";
        ///     
        /// </summary>
        public static String ConnectionString = "mongodb://localhost";

        public static String Server = "DotNetLiguriaDEMO";

        private static MongoDatabase MongoDB()
        {
            var client = new MongoClient(ConnectionString);
            var server = client.GetServer();
            return server.GetDatabase(Server);
        }

        private static void Drop()
        {
            MongoDB().Drop();
        }

        private static MongoCollection<T> CreateConnetion<T>() where T : class
        {
            return MongoDB().GetCollection<T>(GetCollectionName(typeof(T)));
        }

        private static String GetCollectionName(Type document)
        {
            if (document.BaseType == null)
            {
                throw new ArgumentException("The type must be of a Object or one of its extension");
            }

            if (document.BaseType.Name.Equals(typeof(Object).Name))
            {
                return document.Name;
            }

            return GetCollectionName(document.BaseType);
        }

        private static IQueryable<T> Query<T>() where T : class
        {
            return CreateConnetion<T>().AsQueryable<T>();
        }

        private static void BasicPopulate()
        {
            Console.WriteLine("Starting MongoDB Population");
            Drop();

            CreateConnetion<User>().Insert<User>(new User() { Username = "Ale-DotNet", Password = "12345", Name = "Ale", Phone = "347-1234567", Roles = new List<string>() { Roles.Admin } });
            CreateConnetion<User>().Insert<User>(new User() { Username = "Boo-DotNet", Password = "67890", Name = "Maa", Phone = "339-1234567", Roles = new List<string>() { Roles.Operator } });
            Console.WriteLine("Users Added");

            CreateConnetion<Car>().Insert<Car>(new Car() { Make = MakeTypes.Fiat, Model = "500", Engine = new Engine() { Fuel = FuelTypes.Gasoline } });
            CreateConnetion<Car>().Insert<Car>(new Car()
            {
                Make = MakeTypes.Jeep,
                Model = "Renegade",
                Engine = new Engine() { Fuel = FuelTypes.Diesel },
                Image = new CarImage() { Name = "renegade.jpg", Bytes = GetBytes(".\\Images\\renegade.jpg") }
            });

            CreateConnetion<Car>().Insert<Car>(new Car() { Make = MakeTypes.Subaru, Model = "XV", Engine = new Engine() { Fuel = FuelTypes.Diesel } });

            #region Non Base Car
            CreateConnetion<SolarCar>().Insert<SolarCar>(new SolarCar()
            {
                Make = MakeTypes.Helios,
                Model = "ForFree",
                Engine = new Engine() { Fuel = FuelTypes.Solar },
                Panels = new List<Panel>(){new Panel() 
                                               {
                                                   Brand = "Tesla",
                                                   Power = 12
                                               }}
            });

            CreateConnetion<ExtraSolar>().Insert<ExtraSolar>(new ExtraSolar()
            {
                Make = MakeTypes.Helios,
                Model = "ExtraFree",
                Engine = new Engine() { Fuel = FuelTypes.Solar },
                Panels = new List<Panel>(){new Panel() 
                                               {
                                                   Brand = "ExtraTesla",
                                                   Power = 12
                                               }},
                Planet = "Mars"
            });
            #endregion
            Console.WriteLine("Cars Added");

            CreateConnetion<MyNewCar>().Insert<MyNewCar>(new MyNewCar()
            {
                Booo = "NonZo"
            });

            Console.WriteLine("\nClick to continue\n");
            Console.ReadKey();
        }

        private static void BasicRead()
        {
            var document01 = Query<User>().Where(x => x.Name.Equals("Ale")).FirstOrDefault();
            Console.WriteLine("Name: {0}, Phone: {1}", document01.Name, document01.Phone);

            var documentS02 = Query<Car>().Where(x => x.Engine.Fuel.Equals(FuelTypes.Diesel)).ToList();
            Console.WriteLine("Diesel found: {0}", documentS02.Count);
            Console.WriteLine("First Car, Make: {0}, Model: {1}", documentS02.First().Make, documentS02.First().Model);
            Console.WriteLine();

            var allCar = Query<Car>().ToList();
            Console.WriteLine("allCar #: {0}", allCar.Count);

            #region Extra Car
            var solar = Query<ExtraSolar>().ToList();
            Console.WriteLine("Extra #: {0}", solar.Count);

            var extraS = Query<ExtraSolar>().Where(x => x.Planet != null).ToList<ExtraSolar>();
            Console.WriteLine("Extra #: {0}", extraS.Count);
            #endregion



            Console.WriteLine("Click to continue");
            Console.ReadKey();
        }

        private static void GridFSPopulate()
        {
            // Database clean
            Console.WriteLine("GridFS cleaning starting");
            var files = MongoDB().GridFS.FindAll();
            if (files != null)
            {
                foreach (var item in files)
                    MongoDB().GridFS.Delete(item.Name);
            }

            // Database load
            Console.WriteLine("Uploading a file on GridFS");
            using (var fs = new FileStream(".\\Images\\renegade.jpg", FileMode.Open))
            {
                var gridFsInfo = MongoDB().GridFS.Upload(fs, "renegade.jpg");
            }
            Console.WriteLine("File Uploaded to GridFS");
            Console.WriteLine("\nClick to continue\n");
            Console.ReadKey();
        }

        private static void QueryGridFS()
        {
            String localFolder = "LocalFolder";

            var dirInf = Directory.CreateDirectory(localFolder);

            Console.WriteLine("Delete all files in FileSystem");
            foreach (FileInfo file in dirInf.GetFiles())
                file.Delete();

            var files = MongoDB().GridFS.FindAll();
            DateTime startT = DateTime.Now;
            Console.WriteLine("Downloading {0} Files", files.Count());
            Console.WriteLine("Start query time: {0}", startT.ToLongTimeString());
            if (files != null)
            {
                foreach (var item in files)
                {
                    MongoDB().GridFS.Download(String.Concat(localFolder, "/", item.Name), item);
                }
            }
            DateTime endT = DateTime.Now;
            Console.WriteLine("End query time: " + endT.ToLongTimeString());
            Console.WriteLine("Files downloaded... check this folder: {0}", localFolder);
            System.TimeSpan diffResult = endT.Subtract(startT);
            Console.WriteLine("Elapsed Time, Minutes: {0}, Seconds: {1}, MilliSeconds: {2}", diffResult.Minutes, diffResult.Seconds, diffResult.Milliseconds);
            Console.WriteLine("\nClick to continue\n");
            Console.ReadKey();
        }

        private static void ManageExtension()
        {
            BsonClassMap.RegisterClassMap<Car>(cm =>
            {
                cm.AutoMap();
                cm.SetIsRootClass(true);
            });
            BsonClassMap.RegisterClassMap<SolarCar>();
            BsonClassMap.RegisterClassMap<ExtraSolar>();
            BsonClassMap.RegisterClassMap<MyNewCar>();
            
        }

        static void Main(string[] args)
        {
            ManageExtension();
            BasicPopulate();
            BasicRead();

            Console.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------");
            Console.ReadKey();

            // GridFS
            Console.WriteLine("\nStart Testing GridFS\n");
            GridFSPopulate();
            QueryGridFS();
        }

        private static byte[] GetBytes(String fileName)
        {
            byte[] _Buffer = null;
            using (var fs = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                BinaryReader _BinaryReader = new BinaryReader(fs);
                long _TotalBytes = new System.IO.FileInfo(fileName).Length;
                _Buffer = _BinaryReader.ReadBytes((Int32)_TotalBytes);

            }
            return _Buffer;
        }
    }
}
