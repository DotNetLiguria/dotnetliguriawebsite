﻿using System;
using System.Collections.Generic;
using System.Linq;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;

namespace NewWorkbook
{
    class Program
    {
        static void Main(string[] args)
        {
            // OpenXml
            //https://www.nuget.org/packages/DocumentFormat.OpenXml/

            //ClosedXml
            //https://www.nuget.org/packages/ClosedXML/

            Init();

            Console.ReadLine();
            Console.WriteLine("Genero il documento excel");
            HelloWorld();
            Console.ReadLine();

            Console.WriteLine("Leggo il documento excel ed applico uno stile");
            ReadAndEdit();
            Console.ReadLine();

            Console.WriteLine("Leggo il documento excel ed inserisco una tabella");
            CreateTable();
            Console.ReadLine();

            Console.WriteLine("Leggo il documento excel ed inserisco una formula");
            ApplyFormula();

            Console.ReadLine();

            Console.WriteLine("Leggo il documento excel e creo una Pivot Table");
            CreatePivot();
            Console.ReadLine();
        }

        private static void Init()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Title = "DotNet Liguria Workshop 1 Anno 2015: demo ClosedXML";
            Console.WriteLine("Demo ClosedXML");
        }

        /// <summary>
        /// 
        /// </summary>
        public static void HelloWorld()
        {
            // creo il workbook
            var workbook = new XLWorkbook();
            // aggiungo un foglio al workbook
            var worksheet = workbook.Worksheets.Add("Sample Sheet");
            // scrivo nella prima cella
            worksheet.Cell("A1").Value = "Hello World!";
            worksheet.Cell("A1").ShareString = false;
            // salvo il documento
            workbook.SaveAs("HelloWorld.xlsx");
        }

        /// <summary>
        /// Legge e modifica.
        /// </summary>
        public static void ReadAndEdit()
        {
            var workbook = new XLWorkbook("HelloWorld.xlsx");
            var ws = workbook.Worksheet(1);
            // Change the background color of the headers
            var rngHeaders = ws.Range("A1:A1");

            rngHeaders.Style.Fill.BackgroundColor = XLColor.Navy;
            rngHeaders.Style.Font.SetFontColor(XLColor.White);

            workbook.SaveAs("HelloWorld.xlsx");
        }

        /// <summary>
        /// Crea una data table.
        /// </summary>
        private static void CreateTable()
        {
            var workbook = new XLWorkbook("HelloWorld.xlsx");
            var ws = workbook.Worksheets.Add("Orders Data");
            // recupero i dati
            IEnumerable<Order> orders = DataSource.GetOrders().ToList();

            // definisco un nome per un range di celle
            ws.Range(1, 1, 1, 9).Merge().AddToNamed("Titles");

            // creo la tabella 
            var ordersTable = ws.Cell(1, 1).InsertTable(orders.OrderBy(o => o.Country), "OrdersDataTable", true);

            //inserisco una riga con i totali dei prezzi
            ordersTable.ShowTotalsRow = true;

            //dichiaro che la formula da utilizzare per calcolare i totali è la somma
            ordersTable.Field("Price").TotalsRowFunction = XLTotalsRowFunction.Sum;

            // aggiungo un'etichetta alla riga del totale
            ordersTable.Field(0).TotalsRowLabel = "Sum Of Prices";

            // applico uno stile alle celle nel range precedentemente identificato
            var titlesStyle = workbook.Style;
            titlesStyle.Font.Bold = true;
            titlesStyle.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            titlesStyle.Fill.BackgroundColor = XLColor.BabyBlue;


            // Format all titles in one shot
            workbook.NamedRanges.NamedRange("Titles").Ranges.Style = titlesStyle;

            ws.Columns().AdjustToContents();

            workbook.SaveAs("HelloWorld.xlsx");
        }
        /// <summary>
        /// inserisce un set di formule
        /// </summary>
        private static void ApplyFormula()
        {
            var workbook = new XLWorkbook("HelloWorld.xlsx");
            var ws = workbook.Worksheets.Worksheet("Orders Data");


            //cerco la posizione dell'ultima colonna valorizzata presente sul foglio
            var lastColumnCell = ws.FirstRow().CellsUsed().Count();

            //definisco il valore delaa prima cella che sarà il mio titolo
            ws.Cell(1, lastColumnCell + 1).Value = "Total price";

            //per ogni riga applico la formula
            foreach (var row in ws.RowsUsed().Skip(1).Take(ws.RowsUsed().Count() - 2))
            {
                row.Cell(10).SetFormulaA1(string.Format("=(D{0} * E{0} /100) + D{0} ", row.RowNumber()));
                row.Cell(10).Style.NumberFormat.Format = "€ #.##0,00;[Red]-€ #.##0,00";
            }

            //sistemo la larghezza delle colonne
            ws.Columns().AdjustToContents();


            workbook.SaveAs("HelloWorld.xlsx");
        }
        /// <summary>
        /// crea una pivot
        /// </summary>
        private static void CreatePivot()
        {
            var workbook = new XLWorkbook("HelloWorld.xlsx");

            var ws = workbook.Worksheets.Worksheet("Orders Data");


            //recupero la tabella
            var ordersDataTable = ws.Tables.FirstOrDefault(t => t.Name == "OrdersDataTable");
            if (ordersDataTable != null)
            {
                // recupero il range dei dati
                var dataRange = ws.Range(ws.FirstCell(), ordersDataTable.DataRange.LastCell());

                //aggiungo un nuovo foglio
                var ptSheet = workbook.Worksheets.Add("PivotOrders");

                // creo la pivot posizionandola dalla prima cella utilizzando il range di dati
                var pt = ptSheet.PivotTables.AddNew("PivotTable", ptSheet.Cell(1, 1), dataRange);

                //Inserisco le nazioni come righe
                pt.RowLabels.Add("Country");

                //Inserisco i mesi come colonne
                pt.ColumnLabels.Add("Month");

                //Inserisco i prezzi come valori
                pt.Values.Add("Price");


                workbook.SaveAs("HelloWorld.xlsx");
            }
        }

    }
}
