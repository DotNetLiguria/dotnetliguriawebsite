﻿using System;

namespace NewWorkbook
{
    public class Order
    {

        public Order()
        {
            Vat = 22;
        }
        public string Comapny { get; set; }
        public string Country { get; set; }
        public string Product { get; set; }
        public decimal Price { get; set; }

        public decimal Vat { get; set; }
        public DateTime PurchaseDate { get; set; }

        public int Year
        {
            get { return PurchaseDate.Year; }
        }
        public int Month
        {
            get { return PurchaseDate.Month; }
        }
        public string City { get; set; }
    }
}
