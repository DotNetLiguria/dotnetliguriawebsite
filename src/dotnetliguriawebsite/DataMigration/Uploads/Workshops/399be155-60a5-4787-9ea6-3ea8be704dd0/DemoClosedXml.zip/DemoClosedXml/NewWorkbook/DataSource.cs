﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewWorkbook
{
    public static class DataSource
    {
        public static IEnumerable<Order> GetOrders()
        {
            var list = new List<Order>
            {
                new Order
                {
                    Comapny = "Alfreds Futterkiste",
                    Country = "Germany",
                    City = "Berlin",
                    Price = 27.23M,
                    PurchaseDate = new DateTime(2014, 1, 15),
                    Product = "Jack's New England Clam Chowder"
                },
                new Order
                {
                    Comapny = "Ana Trujillo Emparedados y helados",
                    Country = "Mexico",
                    City = "México D.F.",
                    Price = 31.43M,
                    PurchaseDate = new DateTime(2014, 1, 19),
                    Product = "Singaporean Hokkien Fried Mee"
                },
                new Order
                {
                    Comapny = "Antonio Moreno Taquería",
                    Country = "Mexico",
                    City = "México D.F.",
                    Price = 27.35M,
                    PurchaseDate = new DateTime(2014, 2, 4),
                    Product = "Ipoh Coffee"
                },
                new Order
                {
                    Comapny = "Around the Horn",
                    Country = "UK",
                    City = "London",
                    Price = 23.33M,
                    PurchaseDate = new DateTime(2014, 2, 15),
                    Product = "Gula Malacca"
                },
                new Order
                {
                    Comapny = "Berglunds snabbköp",
                    Country = "Sweden",
                    City = "Luleå",
                    Price = 15.21M,
                    PurchaseDate = new DateTime(2014, 2, 18),
                    Product = "Rogede sild"
                },
                new Order
                {
                    Comapny = "Blauer See Delikatessen",
                    Country = "Germany",
                    City = "Mannheim",
                    Price = 32.76M,
                    PurchaseDate = new DateTime(2014, 2, 19),
                    Product = "Spegesild"
                },
                new Order
                {
                    Comapny = "Blondesddsl père et fils",
                    Country = "France",
                    City = "Strasbourg",
                    Price = 28.87M,
                    PurchaseDate = new DateTime(2014, 2, 12),
                    Product = "Zaanse koeken"
                },
                new Order
                {
                    Comapny = "Bólido Comidas preparadas",
                    Country = "Spain",
                    City = "Madrid",
                    Price = 35.14M,
                    PurchaseDate = new DateTime(2014, 3, 12),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "Bon app",
                    Country = "France",
                    City = "Marseille",
                    Price = 35.23M,
                    PurchaseDate = new DateTime(2014, 3, 1),
                    Product = "Maxilaku"
                },
                new Order
                {
                    Comapny = "Bottom-Dollar Markets",
                    Country = "Canada",
                    City = "Tsawassen",
                    Price = 18.65M,
                    PurchaseDate = new DateTime(2014, 1, 1),
                    Product = "Valkoinen suklaa"
                },
                new Order
                {
                    Comapny = "B's Beverages",
                    Country = "UK",
                    City = "London",
                    Price = 34.23M,
                    PurchaseDate = new DateTime(2014, 3, 1),
                    Product = "Manjimup Dried Apples"
                },
                new Order
                {
                    Comapny = "Cactus Comidas para llevar",
                    Country = "Argentina",
                    City = "Buenos Aires",
                    Price = 39.23M,
                    PurchaseDate = new DateTime(2014, 3, 1),
                    Product = "Filo Mix"
                },
                new Order
                {
                    Comapny = "Centro comercial Moctezuma",
                    Country = "Mexico",
                    City = "México D.F.",
                    Price = 21.04M,
                    PurchaseDate = new DateTime(2014, 3, 1),
                    Product = "Perth Pasties"
                },
                new Order
                {
                    Comapny = "Chop-suey Chinese",
                    Country = "Switzerland",
                    City = "Bern",
                    Price = 18.99M,
                    PurchaseDate = new DateTime(2014, 3, 1),
                    Product = "Tourtière"
                },
                new Order
                {
                    Comapny = "Comércio Mineiro",
                    Country = "Brazil",
                    City = "Sao Paulo",
                    Price = 15.32M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Pâté chinois"
                },
                new Order
                {
                    Comapny = "Consolidated Holdings",
                    Country = "UK",
                    City = "London",
                    Price = 33.32M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Gnocchi di nonna Alice"
                },
                new Order
                {
                    Comapny = "Drachenblut Delikatessen",
                    Country = "Germany",
                    City = "Aachen",
                    Price = 26.99M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Ravioli Angelo"
                },
                new Order
                {
                    Comapny = "Du monde entier",
                    Country = "France",
                    City = "Nantes",
                    Price = 27.99M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Escargots de Bourgogne"
                },
                new Order
                {
                    Comapny = "Eastern Connection",
                    Country = "UK",
                    City = "London",
                    Price = 18.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Raclette Courdavault"
                },
                new Order
                {
                    Comapny = "Ernst Handel",
                    Country = "Austria",
                    City = "Graz",
                    Price = 38.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Camembert Pierrot"
                },
                new Order
                {
                    Comapny = "Familia Arquibaldo",
                    Country = "Brazil",
                    City = "Sao Paulo",
                    Price = 18.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Jack's New England Clam Chowder"
                },
                new Order
                {
                    Comapny = "FISSA Fabrica Inter. Salchichas S.A.",
                    Country = "Spain",
                    City = "Madrid",
                    Price = 16.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Camembert Pierrot"
                },
                new Order
                {
                    Comapny = "Folies gourmandes",
                    Country = "France",
                    City = "Lille",
                    Price = 17.99M,
                    PurchaseDate = new DateTime(2014, 1, 1),
                    Product = "Camembert Pierrot"
                },
                new Order
                {
                    Comapny = "Folk och fä HB",
                    Country = "Sweden",
                    City = "Bräcke",
                    Price = 17.99M,
                    PurchaseDate = new DateTime(2014, 1, 1),
                    Product = "Camembert Pierrot"
                },
                new Order
                {
                    Comapny = "Frankenversand",
                    Country = "Germany",
                    City = "München",
                    Price = 38.99M,
                    PurchaseDate = new DateTime(2014, 2, 1),
                    Product = "Raclette Courdavault"
                },
                new Order
                {
                    Comapny = "France restauration",
                    Country = "France",
                    City = "Nantes",
                    Price = 39.99M,
                    PurchaseDate = new DateTime(2014, 2, 1),
                    Product = "Raclette Courdavault"
                },
                new Order
                {
                    Comapny = "Franchi S.p.A.",
                    Country = "Italy",
                    City = "Torino",
                    Price = 43.99M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Raclette Courdavault"
                },
                new Order
                {
                    Comapny = "Furia Bacalhau e Frutos do Mar",
                    Country = "Portugal",
                    City = "Lisboa",
                    Price = 32.99M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Gnocchi di nonna Alice"
                },
                new Order
                {
                    Comapny = "Galería del gastrónomo",
                    Country = "Spain",
                    City = "Barcelona",
                    Price = 27.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Gnocchi di nonna Alice"
                },
                new Order
                {
                    Comapny = "Godos Cocina Típica",
                    Country = "Spain",
                    City = "Sevilla",
                    Price = 39.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Gnocchi di nonna Alice"
                },
                new Order
                {
                    Comapny = "Gourmet Lanchonetes",
                    Country = "Brazil",
                    City = "Campinas",
                    Price = 33.99M,
                    PurchaseDate = new DateTime(2014, 6, 1),
                    Product = "Gnocchi di nonna Alice"
                },
                new Order
                {
                    Comapny = "Great Lakes Food Market",
                    Country = "USA",
                    City = "Eugene",
                    Price = 35.99M,
                    PurchaseDate = new DateTime(2014, 6, 1),
                    Product = "Gnocchi di nonna Alice"
                },
                new Order
                {
                    Comapny = "GROSELLA-Restaurante",
                    Country = "Venezuela",
                    City = "Caracas",
                    Price = 23.99M,
                    PurchaseDate = new DateTime(2014, 6, 1),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "Hanari Carnes",
                    Country = "Brazil",
                    City = "Rio de Janeiro",
                    Price = 20.99M,
                    PurchaseDate = new DateTime(2014, 7, 1),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "HILARION-Abastos",
                    Country = "Venezuela",
                    City = "San Cristóbal",
                    Price = 39.99M,
                    PurchaseDate = new DateTime(2014, 7, 1),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "Hungry Coyote Import Store",
                    Country = "USA",
                    City = "Elgin",
                    Price = 33.99M,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "Hungry Owl All-Night Grocers",
                    Country = "Ireland",
                    City = "Cork",
                    Price = 19,
                    PurchaseDate = new DateTime(2014, 4, 1),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "Island Trading",
                    Country = "UK",
                    City = "Cowes",
                    Price = 43.99M,
                    PurchaseDate = new DateTime(2014, 5, 1),
                    Product = "Chocolade"
                },
                new Order
                {
                    Comapny = "Königlich Essen",
                    Country = "Germany",
                    City = "Brandenburg",
                    Price = 45.99M,
                    PurchaseDate = new DateTime(2014, 2, 1),
                    Product = "Escargots de Bourgogne"
                },
                new Order
                {
                    Comapny = "La corne d'abondance",
                    Country = "France",
                    City = "Versailles",
                    Price = 36.99M,
                    PurchaseDate = new DateTime(2014, 1, 1),
                    Product = "Escargots de Bourgogne"
                }
            };

            return list;
        }
    }
}
